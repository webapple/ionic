export declare class Toolbar {
    style: any;
    styleClass: string;
}
export declare class ToolbarModule {
}
