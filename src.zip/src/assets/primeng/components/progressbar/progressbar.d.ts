export declare class ProgressBar {
    value: any;
    showValue: boolean;
    unit: string;
}
export declare class ProgressBarModule {
}
