import Block from '../blots/block';


class Blockquote extends Block {}
Blockquote.blotName = 'blockquote';
Blockquote.tagName = 'blockquote';


export default Blockquote;
